## ----defaultOptions, echo=FALSE, results="hide", message=FALSE, warning=FALSE, cache=FALSE----
### This chuck sets all the options used by knitr.
library(knitr)
opts_chunk$set(background=c(0.97, 0.97, 0.97), tidy=FALSE, cache=TRUE, dev='pdf', size='footnotesize', fig.align='center', out.width='\\linewidth')
opts_template$set(widefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(rightwidefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(leftwidefigure = list(fig.width=12, fig.height=3, fig.env='figure*', fig.pos='t'))
opts_template$set(marginfigure = list(fig.height=4, fig.width=4, fig.env='marginfigure'))
opts_template$set(figure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
opts_template$set(rightfigure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
opts_template$set(leftfigure = list(fig.height=6, fig.width=6, fig.env='figure', out.width='.8\\linewidth', fig.pos='t'))
options(width = 65, show.signif.stars = FALSE)
hook_output <- knit_hooks$get("output")
knit_hooks$set(output = function(x, options) {
  lines <- options$output.lines
  if (is.null(lines)) {
    hook_output(x, options)  # pass to default hook
  }
  else {
    x <- unlist(stringr::str_split(x, "\n"))
    xx <- character(length(x))
    lines <- seq_along(x)[lines]
    gap <- 0
    j <- k <- 1
    browser()
    for(i in seq_along(x)) {
      if(k <= length(lines) && i == lines[k]) {
        xx[j] <- x[i]
        j <- j + 1
        k <- k + 1
        gap <- 0
      } else if(gap == 0) {
        xx[j] <- "..."
        j <- j + 1
        gap <- 1
      }
    }
    # paste these lines together
    x <- paste(xx[xx != ""], collapse = "\n")
    hook_output(x, options)
  }
})

## ----packages, cache=FALSE, message=FALSE, results="hide", warning=FALSE, echo=FALSE----
library(ggplot2)   ## Grammar of graphics
library(reshape2)  ## Reshaping data frames
library(lattice)   ## More graphics
library(hexbin)    ## and more graphics
library(gridExtra) ## ... and more graphics
library(xtable)    ## LaTeX formatting of tables
library(splines)   ## Splines -- surprise :-)
library(survival)  ## Survival analysis
library(grid)      ## For 'unit'
library(lpSolve)   ## Linear programming

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='LScase/figure/', cache.path='LScase/cache/')

## ----readingData-----------------------------------------------
pregnant <- read.table(
  "http://www.math.ku.dk/~richard/regression/data/pregnant.txt",
  header = TRUE,
  colClasses = c("factor", "factor", "numeric", "factor", "factor",
                 "integer", "factor", "numeric", "factor", "numeric", 
                 "numeric", "integer")
)

## ----dataHead, dependson='readingData'-------------------------
head(pregnant, 4)

## ----variables, dependson='readingData'------------------------
summary(pregnant)

## ----subset, dependson='readingData'---------------------------
pregnant <- subset(pregnant, 
                   weight > 32 & length > 10 & length < 99 & 
                     gestationalAge > 18, 
                   select = -c(interviewWeek, fetalDeath))

## ----histograms, dependson='subset', message=FALSE, warning=FALSE, fig.cap='Density estimates or bar plots of continuous variables or variables taking many values.', opts.label='widefigure'----
tmp <- lapply(names(pregnant), function(x) 
  ggplot(data = pregnant[, x, drop = FALSE]) + 
    aes_string(x) + xlab(x) + ylab(""))
gd <- geom_density(adjust = 2, fill = gray(0.5))
gb <- geom_bar(fill = gray(0.5))
grid.arrange(
  tmp[[1]] + gd,
  tmp[[4]] + gb,
  tmp[[6]] + gb,
  tmp[[8]] + gd,
  tmp[[9]] + gd,
  ncol = 5
)

## ----barplots, dependson='subset', message=FALSE, warning=FALSE, fig.cap='Barplots of variables taking few values.', opts.label='widefigure'----
grid.arrange(
  tmp[[2]] + gb,
  tmp[[3]] + gb,
  tmp[[5]] + gb,
  tmp[[7]] + gb,
  tmp[[10]] + aes(x = factor(feverEpisodes)) + 
    gb + xlab("feverEpisodes"),
  ncol = 5
)

## ----scatterPlotMatrix, dependson='subset', opts.label='leftfigure', fig.cap='Scatter plot matrix of the numeric variables and corresponding Pearson correlations.'----
cor.print <- function(x, y) {
  panel.text(mean(range(x)), mean(range(y)), 
             paste('$', round(cor(x, y), digits = 2), '$', sep = '')
             )
}
contVar <- c("age", "gestationalAge", "alcohol", "length", "weight")        
splom(na.omit(pregnant)[, contVar], xlab = "",
      upper.panel = panel.hexbinplot,
      pscales = 0, xbins = 20,
      varnames = c("age", "gest. age", contVar[3:5]),
      lower.panel = cor.print
)

## ----corMatrix, dependson='subset', fig.height=6, fig.width=4, fig.env='marginfigure', fig.cap='Spearman correlation matrix. Variables are ordered according to a hierarchical clustering.'----
cp <- cor(data.matrix(na.omit(pregnant)), method = "spearman")
ord <- rev(hclust(as.dist(1 - abs(cp)))$order)
colPal <- colorRampPalette(c("blue", "yellow"), space = "rgb")(100)

levelplot(cp[ord, ord],  
          xlab = "", 
          ylab = "",
          col.regions = colPal, 
          at = seq(-1, 1, length.out = 100),
          colorkey = list(space = "top", labels = list(cex = 1.5)),
          scales = list(x = list(rot = 45), 
                        y = list(draw = FALSE),
                        cex = 1.2)
)

## ----margRegCat, dependson=c('subset', 'catContBox'), fig.cap='Boxplots of \\texttt{weight}.', opts.label='leftwidefigure', fig.pos='t', echo=FALSE, warning=FALSE----
mPregnant <- melt(pregnant[, c("weight",
                           "abortions",
                           "children",
                           "smoking",
                           "coffee",
                           "feverEpisodes")], 
                  id = "weight")
ggplot(mPregnant, 
       aes(x = factor(value, levels = 0:10), y = weight)) + 
  geom_boxplot(fill = I(gray(0.8))) + xlab("") +
  facet_wrap(~ variable, scale = "free_x", ncol = 5) 

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='LScase/figure/', cache.path='LScase/cache/')

## ----singleTermInclusion, dependson='subset'-------------------
form <- weight ~ gestationalAge + length + age + children +
  coffee + alcohol + smoking + abortions + feverEpisodes
pregnant <- na.omit(pregnant)
nulModel <- lm(weight ~ 1, data = pregnant)
oneTermModels <- add1(nulModel, form, test = "F")

## ----singleTermInclusionPrint, dependson='singleTermInclusion', results='asis', echo=FALSE----
Forder <- with(oneTermModels[-1, ], order(get('Pr(>F)'), -get('F value')))
print(xtable(   ## For LaTeX formatting
  oneTermModels[-1, ][Forder, -4],
  digits = c(2, 2, 3, 3, 2, 3),
  display = c('s', 'd', 'e', 'e', 'f', 'g'),
),
  floating = FALSE,
  math.style.negative = TRUE
)

## ----margReg, dependson='singleTermInclusion', warning=FALSE, message=FALSE, fig.cap="Scatter plots including linear regression line.", opts.label='widefigure'----
mPregnant <- melt(pregnant[, contVar],
                  id.vars = "weight")
binScale <- scale_fill_continuous(breaks = c(1, 10, 100, 1000),
                                  low = "gray80", high = "black",
                                  trans = "log", guide = "none")
qplot(value, weight, data = mPregnant, xlab = "", geom = "hex") +
  stat_binhex(bins = 25) + binScale +
  facet_wrap(~ variable, scales = "free_x", ncol =  4) +
  geom_smooth(size = 1, method = "lm")

## ----regModel, dependson='singleTermInclusion', results='hide'----
form <- update(form, . ~ . - length)
pregnantLm <- lm(form, data = pregnant)
summary(pregnantLm)

## ----regModelPrint, dependson='singleTermInclusion', echo=FALSE, results='asis'----
print(xtable(
  summary(pregnantLm),
  digits = c(2, 2, 2, 2, 2),
  display = c('s', 'f', 'f', 'f', 'g'),
),
  floating = FALSE,
  math.style.negative = TRUE,
)

## ----anovaTab, dependson='regModel', results='hide'------------
drop1(pregnantLm, test = "F")

## ----anovaTabPrint, dependson='regModel', echo = FALSE, results='asis'----
tmp <- drop1(pregnantLm, test = "F")[-1, c(1, 6)]
rownames(tmp)[1] <- "gest. Age"
tmp <- tmp[order(tmp[, 2]), ]
print(xtable(
  tmp,
  digits = c(2, 2, 2),
  display = c('s', 'd', 'g'),
  ),
      floating = FALSE,
      math.style.negative = TRUE
)

## ----modelControl, dependson='regModel', results='hide', fig.keep='none', warning=FALSE, message=FALSE----
pregnantDiag <- fortify(pregnantLm)

p1 <- qplot(.fitted, .stdresid, data = pregnantDiag, geom = "hex") +
  binScale + geom_smooth(size = 1) +
  xlab("fitted values") + ylab("standardized residuals")
p2 <- qplot(gestationalAge, .stdresid, data = pregnantDiag,
            geom = "hex") + binScale +
  stat_binhex(bins = 25) + geom_smooth(size = 1) +
  xlab("gestationalAge") + ylab("")
p3 <- qplot(sample = .stdresid, data = pregnantDiag, stat = "qq") +
  geom_abline(intercept = 0, slope = 1, color = "blue", size = 1) +
  xlab("theoretical quantiles") + ylab("")
grid.arrange(p1, p2, p3, ncol = 3)

## ----modelControlPlot, dependson='modelControl', warning=FALSE, message=FALSE, fig.cap="Diagnostic plots. Standardized residuals plotted against fitted values, the predictor \\texttt{gestationalAge}, and a qq-plot against the normal distribution.", fig.width=9, fig.height=3, fig.env='leftfigure', echo=FALSE----
tmp <- as.data.frame(with(pregnantDiag, qqnorm(.stdresid, plot.it = FALSE)))
p3 <- qplot(x, y, data = tmp[!duplicated(round(tmp$x, 2)), ]) +
  geom_abline(intercept = 0, slope = 1, color = "blue") +
  xlab("theoretical quantiles") + ylab("")
grid.arrange(p1, p2, p3, ncol = 3)

## ----interactionPlot, dependson='singleTermModels', warning=FALSE, message=FALSE, fig.cap="Scatter plots of \\texttt{weight} against \\texttt{gestationalAge} stratified according to the values of \\texttt{smoking}, \\texttt{children} and \\texttt{coffee}", fig.width=12, fig.height=6, fig.env='rightwidefigure'----
qplot(gestationalAge, weight, data = pregnant, geom = "hex") +
  facet_grid(coffee ~ children + smoking, label = label_both) +
  binScale + stat_binhex(bins = 25) +
  geom_smooth(method = "lm", size = 1, se = FALSE)

## ----interactionModel, dependson=c('singleTermInclusions', 'regModel'), results='hide'----
form <- weight ~ smoking * coffee * children * gestationalAge +
  age + alcohol + abortions + feverEpisodes
pregnantLm2 <- lm(form, data = pregnant)
anova(pregnantLm, pregnantLm2)

## ----interactionPlot2, dependson='singleTermModels', warning=FALSE, message=FALSE, fig.cap="Comparison of estimated  regression lines for \\texttt{gestationalAge} stratified according to the values of \\texttt{smoking}, \\texttt{coffee} and \\texttt{children}", opts.label='leftwidefigure'----
ggplot(pregnant, aes(gestationalAge, weight, color = coffee)) +
  facet_grid(. ~ children + smoking, label = label_both) +
  geom_smooth(method = "lm", size = 1, se = FALSE)

## ----interactionModelPrint, dependson='interactionModel', results='asis', echo=FALSE----
print(xtable(
  anova(pregnantLm, pregnantLm2),
  digits = c(2, 10, 5, 10, 5, 3, 4),
  display = c('s', 'd', 'g', 'd', 'g', 'g', 'g')
),
  floating = FALSE,
  math.style.negative = TRUE
)

## ----modelControl2, dependson='interactionModel', warning=FALSE, message=FALSE, opts.label='marginfigure', fig.cap='Residual plot for the third order interaction model.'----
pregnantDiag2 <- fortify(pregnantLm2)
qplot(.fitted, .stdresid, data = pregnantDiag2, geom = "hex") +
  binScale + geom_smooth(size = 1) +
  xlab("fitted values") + ylab("standardized residuals")

## ----finalModel, dependson=c('interactionModel', 'singleTermInclusion'), results='hide'----
form <- weight ~ smoking * coffee * children * gestationalAge
pregnantLm3 <- lm(form, data = pregnant)
anova(pregnantLm3, pregnantLm2)

## ----interactionModelPrint2, dependson='interactionModel', results='asis', echo=FALSE----
print(xtable(
  anova(pregnantLm3, pregnantLm2),
  digits = c(2, 10, 5, 10, 5, 3, 4),
  display = c('s', 'd', 'g', 'd', 'g', 'g', 'g')
),
  floating = FALSE,
  math.style.negative = TRUE
)

## ----echo=FALSE, eval=FALSE------------------------------------
#  tmp <- rowSums(predict(pregnantLm2, type = "terms")[, -c(5:8)]) - coefficients(pregnantLm2)[1]
#  temp <- cbind(pregnant, tmp)
#  ggplot(temp, aes(gestationalAge, tmp)) +
#    facet_grid(smoking ~ coffee + children, label = label_both) +
#    geom_smooth(aes(y = weight), method = "lm", size = 1) + geom_line(color = "red")

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='figure/', cache.path='cache/')

## ----splineRegModel, dependson=c('singleTermInclusion', 'regModel'), results='hide'----
nsg <- function(x)
  ns(x, knots = c(38, 40, 42), Boundary.knots = c(25, 47))
form <- weight ~ nsg(gestationalAge) + ns(age, df = 3) + children +
  coffee + alcohol + smoking + abortions + feverEpisodes
pregnantLm3 <- lm(form, data = pregnant)
anova(pregnantLm, pregnantLm3)

## ----splineTest, dependson='splineRegModel', echo=FALSE, results='asis'----
print(
  xtable(
    anova(pregnantLm, pregnantLm3),
    digits = c(2, 10, 5, 10, 5, 3, 4),
    display = c('s', 'd', 'g', 'd', 'g', 'g', 'g')
  ),
  floating = FALSE,
  math.style.negative = TRUE
)

## ----modelControlPlot2, dependson='splineRegModel', warning=FALSE, message=FALSE, fig.cap="Diagnostic plots for the model with \\texttt{gestationalAge} expanded using splines.", fig.width=9, fig.height=3, fig.env='figure', echo=FALSE----
  pregnantDiag <- cbind(fortify(pregnantLm3), pregnant[, "gestationalAge", drop = FALSE])
p1 <- qplot(.fitted, .stdresid, data = pregnantDiag, geom = "hex") +
  binScale + geom_smooth(size = 1) +
  xlab("fitted") + ylab("standardized residuals")
p2 <- qplot(gestationalAge, .stdresid, data = pregnantDiag,
            geom = "hex") + binScale +
  stat_binhex(bins = 25) + geom_smooth(size = 1) +
  xlab("gestationalAge") + ylab("")
tmp <- as.data.frame(with(pregnantDiag, qqnorm(.stdresid, plot.it = FALSE)))
p3 <- qplot(x, y, data = tmp[!duplicated(round(tmp$x, 2)), ]) +
  geom_abline(intercept = 0, slope = 1, color = "blue") +
  xlab("theoretical quantiles") + ylab("")
grid.arrange(p1, p2, p3, ncol = 3)

## ----splineRegModel2, dependson=c('singleTermInclusion', 'splineRegModel'), results='hide'----
form <- weight ~ nsg(gestationalAge) + children + coffee + smoking
pregnantLm4 <- lm(form, data = pregnant)
anova(pregnantLm4, pregnantLm3)

## ----splineTest2, dependson='splineRegModel2', echo=FALSE, results='asis'----
print(
  xtable(
    anova(pregnantLm4, pregnantLm3),
    digits = c(2, 10, 5, 10, 5, 3, 4),
    display = c('s', 'd', 'g', 'd', 'g', 'g', 'g')
  ),
  floating = FALSE,
  math.style.negative = TRUE
)

## ----nonlinearFit, dependson='splineRegModel2', fig.cap='Main effects model with basis expansion of \\texttt{gestationalAge}. Here illustrations of the fitted mean and 95\\% confidence bands for \\texttt{children=1}.', fig.width=9, fig.height=3, fig.env='rightfigure'----
predFrame <- expand.grid(children = factor(1),
                         smoking = factor(c(1, 3)),
                         coffee = factor(c(1, 3)),
                         gestationalAge = seq(25, 47, 0.1),
                         alcohol = 0,
                         age = median(pregnant$age),
                         feverEpisodes = 0,
                         abortions = factor(0)
                         )
predGest <- predict(pregnantLm3, newdata = predFrame,
                    interval = "confidence")
predFrame <- cbind(predFrame, predGest)
qplot(gestationalAge, fit, data = predFrame, geom = "line",
      color = coffee) + ylab("weight") +
  geom_ribbon(aes(ymin = lwr, ymax = upr, fill = coffee),
              alpha = 0.3) +
  facet_grid(. ~ smoking, label = label_both)

## ----dependson='splineRegModel2', results='asis', echo=FALSE----
print(xtable(
  confint(pregnantLm3)[c(9, 10, 11, 13, 14), ],
  digits = c(2, 2, 2),
  display = c('s', 'f', 'f'),
),
      floating = FALSE,
      math.style.negative = TRUE
)

## ----interRegModel2, dependson=c('singleTermInclusion', 'splineRegModel'), results='hide'----
form <- weight ~ (smoking + coffee + children) * nsg(gestationalAge) +
   ns(age, df = 3) + alcohol + abortions + feverEpisodes
pregnantLm5 <- lm(form, data = pregnant)
anova(pregnantLm4, pregnantLm5)

## ----splineInterTest2, dependson=c('interRegModel2', 'splineRegModel2'), echo=FALSE, results='asis'----
print(
  xtable(
    anova(pregnantLm3, pregnantLm5),
    digits = c(2, 10, 5, 10, 5, 3, 4),
    display = c('s', 'd', 'g', 'd', 'g', 'g', 'g')
  ),
  floating = FALSE,
  math.style.negative = TRUE,
)

## ----interRegModel3, dependson=c('singleTermInclusion', 'splineRegModel', 'interRegModel2'), results='hide', echo=FALSE----
form <- weight ~ (smoking * coffee * children) * nsg(gestationalAge)
pregnantLm6 <- lm(form, data = pregnant)
anova(pregnantLm5, pregnantLm6)

## ----predCompar, dependson=c('interRegModel2', 'splineRegModel2'), fig.cap='Comparison of the interaction model (red, 95\\% gray confidence bands) with the reduced nonlinear main effects model (blue).', fig.width=12, fig.height=6, fig.env='figure*', fig.pos='t'----
predFrame <- expand.grid(children = factor(c(0, 1)),
                         smoking = factor(c(1, 2, 3)),
                         coffee = factor(c(1, 2, 3)),
                         gestationalAge = 25:47,
                         alcohol = 0,
                         age = median(pregnant$age),
                         feverEpisodes = 0,
                         abortions = factor(0)
                         )
predFrame <- cbind(predFrame,
  predict(pregnantLm5, newdata = predFrame, interval = "confidence")
)
predFrame$fit4 <- predict(pregnantLm4, newdata = predFrame)
ggplot(predFrame, aes(gestationalAge, fit)) +
  facet_grid(coffee ~ children + smoking, label = label_both) +
  geom_ribbon(aes(ymin = lwr, ymax = upr), fill = gray(0.85)) +
  geom_line(color = "red") + coord_cartesian(ylim = c(0, 5000)) +
  geom_line(aes(y = fit4), color = "blue") + ylab("weight") +
  scale_y_continuous(breaks = c(1000, 2000, 3000, 4000))

## ----echo=FALSE, cache=FALSE-----------------------------------
opts_chunk$set(fig.path='figure/', cache.path='cache/')

